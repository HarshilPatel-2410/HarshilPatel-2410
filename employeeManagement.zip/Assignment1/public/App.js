class EmployeeDirectory extends React.Component {
  render() {
    return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("tr", null));
  }

}

class EmployeeSearch extends React.Component {
  render() {
    return /*#__PURE__*/React.createElement(React.Fragment, null);
  }

}

class EmployeeTable extends React.Component {
  render() {
    return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("h2", {
      class: "title"
    }, "Employee Details:"), /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("div", {
      class: "container"
    }, /*#__PURE__*/React.createElement("table", {
      class: "table"
    }, /*#__PURE__*/React.createElement("thead", {
      class: "thead-light"
    }, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "FirstName"), /*#__PURE__*/React.createElement("th", null, "LastName"), /*#__PURE__*/React.createElement("th", null, "Age"), /*#__PURE__*/React.createElement("th", null, "DateOfJoining"), /*#__PURE__*/React.createElement("th", null, "Title"), /*#__PURE__*/React.createElement("th", null, "Department"), /*#__PURE__*/React.createElement("th", null, "EmployeeType"), /*#__PURE__*/React.createElement("th", null, "CurrentStatus"))), "0    ", /*#__PURE__*/React.createElement("tbody", null, /*#__PURE__*/React.createElement(EmployeeDirectory, null)))));
  }

}

class EmployeeCreate extends React.Component {
  render() {
    return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("h1", {
      class: "title"
    }, "Create Employee :"), /*#__PURE__*/React.createElement("div", {
      class: "container"
    }, /*#__PURE__*/React.createElement("form", {
      class: "employeedetail"
    }, /*#__PURE__*/React.createElement("div", {
      class: "row"
    }, /*#__PURE__*/React.createElement("div", {
      class: "col-md-6"
    }, /*#__PURE__*/React.createElement("label", {
      htmlFor: "fname"
    }, "Enter Your First Name:"), /*#__PURE__*/React.createElement("input", {
      class: "form-control",
      type: "text"
    }), /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("label", {
      htmlFor: "age"
    }, "Enter Your Age:"), /*#__PURE__*/React.createElement("input", {
      class: "form-control",
      type: "number"
    }), /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("label", {
      htmlFor: "title"
    }, "Select your job title:"), /*#__PURE__*/React.createElement("select", {
      class: "form-control",
      name: "title",
      id: "title"
    }, /*#__PURE__*/React.createElement("option", {
      value: "employee"
    }, "Employee"), /*#__PURE__*/React.createElement("option", {
      value: "manager"
    }, "Manager"), /*#__PURE__*/React.createElement("option", {
      value: "director"
    }, "Director"), /*#__PURE__*/React.createElement("option", {
      value: "vp"
    }, "VP")), /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("label", {
      htmlFor: "employeetype"
    }, "Select Employee Type:"), /*#__PURE__*/React.createElement("select", {
      class: "form-control",
      name: "employeetype",
      id: "employeetype"
    }, /*#__PURE__*/React.createElement("option", {
      value: "fulltime"
    }, "Full Time"), /*#__PURE__*/React.createElement("option", {
      value: "parttime"
    }, "Part Time"), /*#__PURE__*/React.createElement("option", {
      value: "contract"
    }, "Contract"), /*#__PURE__*/React.createElement("option", {
      value: "seasonal"
    }, "Seasonal")), /*#__PURE__*/React.createElement("br", null)), /*#__PURE__*/React.createElement("div", {
      class: "col-md-6"
    }, /*#__PURE__*/React.createElement("label", {
      htmlFor: "lname"
    }, "Enter Your Last Name:"), /*#__PURE__*/React.createElement("input", {
      class: "form-control",
      type: "text"
    }), /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("label", {
      htmlFor: "dateofjoining"
    }, "Please select your date of joining:"), /*#__PURE__*/React.createElement("input", {
      class: "form-control",
      type: "date"
    }), /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("label", {
      htmlFor: "department"
    }, "Select your Department:"), /*#__PURE__*/React.createElement("select", {
      class: "form-control",
      name: "department",
      id: "department"
    }, /*#__PURE__*/React.createElement("option", {
      value: "it"
    }, "IT"), /*#__PURE__*/React.createElement("option", {
      value: "marketing"
    }, "Marketing"), /*#__PURE__*/React.createElement("option", {
      value: "hr"
    }, "HR"), /*#__PURE__*/React.createElement("option", {
      value: "engineering"
    }, "Engineering")), /*#__PURE__*/React.createElement("br", null))), /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("button", {
      type: "button",
      class: "btn btn-primary",
      value: "Submit"
    }, "Submit"), /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("br", null))));
  }

}

class Employee extends React.Component {
  render() {
    return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(EmployeeCreate, null), /*#__PURE__*/React.createElement(EmployeeSearch, null), /*#__PURE__*/React.createElement(EmployeeTable, null));
  }

}

const element = /*#__PURE__*/React.createElement(Employee, null);
ReactDOM.render(element, document.getElementById('contents'));