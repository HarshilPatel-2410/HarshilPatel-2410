class EmployeeDirectory extends React.Component{
    render(){
        return(
            <React.Fragment>
                <tr>

                </tr>
            </React.Fragment>
        ) 
    }
}

class EmployeeSearch extends React.Component{
    render(){
        return(
            <React.Fragment>

            </React.Fragment>
        ) 
    }
}

class EmployeeTable extends React.Component{
        render() {
            return(
                <React.Fragment>
        <h2 class="title">Employee Details:</h2>
        <br></br>
    <div class="container">
       <table class="table">
            <thead class="thead-light">
                <tr>
                    <th>FirstName</th>
                    <th>LastName</th>
                    <th>Age</th>
                    <th>DateOfJoining</th>
                    <th>Title</th>
                    <th>Department</th>
                    <th>EmployeeType</th>
                    <th>CurrentStatus</th>
                </tr>
            </thead>
       0    <tbody>
                <EmployeeDirectory />
            </tbody>
        </table>
</div>
                </React.Fragment>
            );
        }
    }

class EmployeeCreate extends React.Component{
    render(){
        return(
            <React.Fragment>
                <h1 class="title">Create Employee :</h1>
                <div class="container">
                <form class="employeedetail">
                    <div class="row">
                        <div class="col-md-6">
                        <label htmlFor="fname">Enter Your First Name:</label>
                        <input class="form-control" type="text"></input><br></br>

                        <label htmlFor="age">Enter Your Age:</label>
                        <input class="form-control" type="number"></input><br></br>

                        <label htmlFor="title">Select your job title:</label>
                        <select class="form-control" name="title" id="title">
                            <option value="employee">Employee</option>
                            <option value="manager">Manager</option>
                            <option value="director">Director</option>
                            <option value="vp">VP</option>
                        </select><br></br>

                        <label htmlFor="employeetype">Select Employee Type:</label>
                        <select class="form-control" name="employeetype" id="employeetype">
                            <option value="fulltime">Full Time</option>
                            <option value="parttime">Part Time</option>
                            <option value="contract">Contract</option>
                            <option value="seasonal">Seasonal</option>
                        </select><br></br>

                        </div>

                        <div class="col-md-6">
                        <label htmlFor="lname">Enter Your Last Name:</label>
                        <input class="form-control" type="text"></input><br></br>

                        <label htmlFor="dateofjoining">Please select your date of joining:</label>
                        <input class="form-control" type="date"></input><br></br>

                        <label htmlFor="department">Select your Department:</label>
                        <select class="form-control" name="department" id="department">
                            <option value="it">IT</option>
                            <option value="marketing">Marketing</option>
                            <option value="hr">HR</option>
                            <option value="engineering">Engineering</option>
                        </select><br></br>

                        </div>
                    </div><br></br>

                    <button type="button" class="btn btn-primary" value="Submit">Submit</button><br></br><br></br>

                </form>
                </div>
            </React.Fragment>
        )
    }

}

class Employee extends React.Component{
    render(){
        return(
            <React.Fragment>
                <EmployeeCreate></EmployeeCreate>
                <EmployeeSearch></EmployeeSearch>
                <EmployeeTable></EmployeeTable>

            </React.Fragment>
        )
    }
}

const element = <Employee></Employee>;
ReactDOM.render(element, document.getElementById('contents'));